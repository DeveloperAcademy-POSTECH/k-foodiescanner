//
//  K_foodie_CameraTests.swift
//  K-foodie CameraTests
//
//  Created by Libby on 8/25/25.
//

import Testing
@testable import K_foodie_Camera

struct K_foodie_CameraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
