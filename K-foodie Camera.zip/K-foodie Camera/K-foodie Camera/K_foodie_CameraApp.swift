//
//  K_foodie_CameraApp.swift
//  K-foodie Camera
//
//  Created by Libby on 8/25/25.
//

import SwiftUI

@main
struct K_foodie_CameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
